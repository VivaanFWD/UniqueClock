#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
//Enter Seconds  -->By Users
//Hours-->
        //1Hours = 3600Seconds
        //4000/3600 = 1h----->400s
//Minutes-->
        //1Minute = 60Seconds
        //(4000-3600)/60 =6m------>40s
//Remaining Seconds
        //(4000-3600)%60 =40s
int main()
{
    int Seconds,Hours,Minutes,RemainingSeconds;
    int H,M,S;

    printf("//Credit:\n//--Developed By Vivaan\n//--Contact @VivaanFWD\n//--SourceCode Avail on Github @VivaanFWD\n//--Program Type: Console\n//--Language_Used:C_Language\n//--Project_Name:UniqueClock\n\n");

    //Taking Input From User in Seconds
    printf("Enter Seconds:\n");
    scanf("%i",&Seconds);

    Hours=(Seconds/3600);

    Minutes=(Seconds-3600*Hours)/60;

    RemainingSeconds=(Seconds-3600)%60;
//Print In The Correct Form Of Timing Like-->HH:MM:SS
    printf("------------------------------------------------------------------");

    printf("\nCorrect Way to Display Timing :");
    if(Hours<10 || Hours==0){
        H=printf("0%d:",Hours);
    }
    else{
        H=printf("%d:",Hours);
    }
    if(Minutes<10 || Minutes==0){
        M=printf("0%d:",Minutes);
    }
    else{
       M= printf("%d:",Minutes);
    }
    if(RemainingSeconds<10 || RemainingSeconds==0){
        S=printf("0%d",RemainingSeconds);
    }
    else{
        S=printf("%d",RemainingSeconds);
    }
    printf("\n------------------------------------------------------------------");
//Bad Way of Timing Arranged
    printf("\n\nNot a Perfect Way of Time Displayed: %d:%d:%d\n\n",Hours,Minutes,RemainingSeconds);
    printf("\n------------------------------------------------------------------");
    printf("\n------------------------------------------------------------------");



    return 0;



}
